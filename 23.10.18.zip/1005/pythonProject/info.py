import osgaka

os.startfile('승패마진표 (2022년).xlsx')